def depthFirstSearch(problem):
    from util import Stack

    stack = Stack()
    visited = set()
    stack.push((problem.getStartState(), [], 0))

    while not stack.isEmpty():
        currentState, actions, currentCost = stack.pop()

        if problem.isGoalState(currentState):
            return actions

        if currentState not in visited:
            visited.add(currentState)
            for nextState, action, cost in problem.getSuccessors(currentState):
                if nextState not in visited:
                    newActions = actions + [action]
                    stack.push((nextState, newActions, currentCost + cost))

    return []